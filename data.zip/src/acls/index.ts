export * from './school.acl';
export * from './user.acl';

