// import {inject} from '@loopback/context';
// import {Binding, Component} from '@loopback/core';
// import {MySocketPushService, SocketPusherBindings} from './socket-pusher.service';

// export class SocketPusherComponent implements Component {

//   bindings: Binding[];
//   /**
//    *
//    */
//   constructor(
//     @inject(SocketPusherBindings.SOCKET_PUSHER_SERVICE) private pusherService: MySocketPushService
//   ) {

//     // this.bindings = [
//     //   // Binding.bind(MySocketBindings.MY_APPLICATION_INSTANCE).
//     //   //   toProvider(MySocketApplicationProvider).inScope(BindingScope.SINGLETON),

//     // ]

//     console.log('Socket bindings set up')
//     pusherService.setup();

//   }





// }
